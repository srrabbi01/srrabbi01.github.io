from django.contrib import admin
from app_article.models import Article
# Register your models here.
admin.site.register(Article)