from django.contrib import admin
from app_forum.models import Forum,Discussion
# Register your models here.
admin.site.register(Forum)
admin.site.register(Discussion)